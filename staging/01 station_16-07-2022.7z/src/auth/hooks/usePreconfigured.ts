import preconfigured from "config/preconfigured.json"

const usePreconfigured = () => {
  return preconfigured as PreconfiguredWallet[]
}

export default usePreconfigured
