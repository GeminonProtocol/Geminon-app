import { ReactComponent as Logo } from "./AnchorEarnLogo.svg"
import "./AnchorEarnLogo.scss"

const AnchorEarnLogo = () => {
  return <Logo />
}

export default AnchorEarnLogo
