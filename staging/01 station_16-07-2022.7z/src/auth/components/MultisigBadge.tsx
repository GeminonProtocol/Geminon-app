import GroupsIcon from "@mui/icons-material/Groups"

const MultisigBadge = () => {
  return <GroupsIcon fontSize="small" />
}

export default MultisigBadge
